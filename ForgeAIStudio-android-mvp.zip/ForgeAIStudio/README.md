# Forge AI Studio — Android MVP

A native Android app for a personal AI image/video workflow:

- **Qwen Image 2** — text-to-image + single-reference image editing
- **Qwen Image Edit 2511** — 1–3 reference multi-image editing
- **LTX‑2.3 Fast** — text-to-video + image-to-video, first/last-frame interpolation, camera controls, synchronized audio
- One-tap **Animate with LTX** from any Qwen image result
- Local generation history
- Save images/videos to Android Gallery
- Share videos through Android
- Replicate API token encrypted with Android Keystore

## Why Replicate for v0.1

The app calls official Replicate model endpoints directly from the phone. This avoids Hugging Face ZeroGPU daily quotas and avoids maintaining a 24/7 GPU server. The API token is encrypted locally and is never hard-coded into the APK.

Current model IDs:

- `qwen/qwen-image-2`
- `qwen/qwen-image-edit-2511`
- `lightricks/ltx-2.3-fast`

## Build

1. Install the latest stable Android Studio.
2. Open this folder as an Android Studio project.
3. Let Android Studio install Android SDK 35 if needed and sync Gradle.
4. Connect your Android phone with USB debugging enabled.
5. Run the `app` configuration.

The project targets Android 15 / API 35 and supports Android 10+ (minSdk 29), so it will run on newer Android versions as well.

## First launch

1. Create a Replicate account.
2. Add billing/credits as required by Replicate.
3. Create an API token in Replicate account settings.
4. Open **Settings** in Forge AI Studio.
5. Paste the token, tap **Save token**, then **Test**.
6. Open Image or Video Studio.

## Important provider behavior

Replicate API output URLs expire, so the app immediately downloads every successful result into its private local `creations` folder. The History tab therefore continues to work after the provider URL expires.

Reference images are resized to a maximum 2048px dimension and JPEG-compressed before being embedded as data URIs for the API. This keeps phone uploads manageable while retaining good source quality.

## v0.2 ideas

- Optional private RunPod backend adapter
- Qwen Image 2 Pro toggle
- True Replicate file upload for very large references
- Queue/cancel UI
- Prompt presets and saved styles
- Side-by-side before/after viewer
- Video extend/retake via LTX 2.3 Pro
- Per-generation cost estimator and monthly budget guardrail

## Build an APK with GitHub Actions (no Android Studio required)

This repo includes `.github/workflows/build-apk.yml`.

1. Put the project in a GitHub repository.
2. Open the repository's **Actions** tab.
3. Run **Build Android APK**.
4. Download the `ForgeAIStudio-debug-apk` artifact.
5. Transfer `app-debug.apk` to your phone and install it (Android may ask you to allow installs from that source).

For a personal device this debug APK is enough. A later release build can be signed with your own Android signing key.
