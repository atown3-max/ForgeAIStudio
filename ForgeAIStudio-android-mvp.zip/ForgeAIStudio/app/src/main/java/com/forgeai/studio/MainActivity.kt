package com.forgeai.studio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.text.DateFormat
import java.util.Date

enum class Screen { IMAGE, VIDEO, HISTORY, SETTINGS }
enum class ImageModel(val label: String) {
    QWEN2("Qwen Image 2"),
    QWEN2511("Qwen Edit 2511 · Multi-reference")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ForgeApp() }
    }
}

@Composable
fun ForgeApp() {
    val context = LocalContext.current
    val tokenStore = remember { SecureTokenStore(context) }
    val historyStore = remember { HistoryStore(context) }
    val client = remember { ReplicateClient { tokenStore.load() } }
    var screen by remember { mutableStateOf(if (tokenStore.load().isNullOrBlank()) Screen.SETTINGS else Screen.IMAGE) }
    var historyVersion by remember { mutableIntStateOf(0) }
    var animateFile by remember { mutableStateOf<File?>(null) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9EA7FF), background = Color(0xFF0B0D12), surface = Color(0xFF12151D))) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF10131A)) {
                    listOf(
                        Screen.IMAGE to "Image",
                        Screen.VIDEO to "Video",
                        Screen.HISTORY to "History",
                        Screen.SETTINGS to "Settings"
                    ).forEach { (target, label) ->
                        NavigationBarItem(
                            selected = screen == target,
                            onClick = { screen = target },
                            icon = { Text(label.take(1), fontWeight = FontWeight.Bold) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.IMAGE -> ImageStudio(
                        client = client,
                        historyStore = historyStore,
                        onHistoryChanged = { historyVersion++ },
                        onAnimate = { file -> animateFile = file; screen = Screen.VIDEO },
                        openSettings = { screen = Screen.SETTINGS }
                    )
                    Screen.VIDEO -> VideoStudio(
                        client = client,
                        historyStore = historyStore,
                        initialFile = animateFile,
                        consumeInitialFile = { animateFile = null },
                        onHistoryChanged = { historyVersion++ },
                        openSettings = { screen = Screen.SETTINGS }
                    )
                    Screen.HISTORY -> HistoryScreen(
                        historyStore = historyStore,
                        refreshKey = historyVersion,
                        onAnimate = { file -> animateFile = file; screen = Screen.VIDEO },
                        onChanged = { historyVersion++ }
                    )
                    Screen.SETTINGS -> SettingsScreen(tokenStore, client) { screen = Screen.IMAGE }
                }
            }
        }
    }
}

@Composable
private fun StudioHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ImageStudio(
    client: ReplicateClient,
    historyStore: HistoryStore,
    onHistoryChanged: () -> Unit,
    onAnimate: (File) -> Unit,
    openSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var model by remember { mutableStateOf(ImageModel.QWEN2) }
    var refs by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("1:1") }
    var matchInput by remember { mutableStateOf(true) }
    var expandPrompt by remember { mutableStateOf(true) }
    var seedText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<File?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        refs = uris.take(if (model == ImageModel.QWEN2511) 3 else 1)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { StudioHeader("Image Studio", "Generate or edit with Qwen. Then send the result straight to LTX.") }
        item {
            OptionRow(
                label = "Model",
                options = ImageModel.entries.map { it.label },
                selected = model.label,
                onSelect = { chosen ->
                    model = ImageModel.entries.first { it.label == chosen }
                    if (model == ImageModel.QWEN2 && refs.size > 1) refs = refs.take(1)
                }
            )
        }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (refs.isEmpty()) "No reference image" else "${refs.size} reference image${if (refs.size == 1) "" else "s"}")
                    if (refs.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            refs.take(3).forEach { uri ->
                                AsyncImage(uri, null, Modifier.size(88.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                            }
                        }
                    }
                    Button(onClick = { picker.launch("image/*") }, enabled = !busy) {
                        Text(if (model == ImageModel.QWEN2511) "Choose up to 3 images" else "Choose image (optional)")
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text(if (refs.isEmpty()) "Describe the image" else "Describe the edit") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { OptionRow("Aspect ratio", listOf("1:1", "16:9", "9:16", "4:3", "3:4", "3:2", "2:3", "2:1", "1:2"), ratio) { ratio = it } }
        if (model == ImageModel.QWEN2) {
            item { ToggleRow("Match input image size", matchInput && refs.isNotEmpty(), enabled = refs.isNotEmpty()) { matchInput = it } }
            item { ToggleRow("Prompt expansion", expandPrompt) { expandPrompt = it } }
            item {
                OutlinedTextField(
                    value = negative,
                    onValueChange = { negative = it },
                    label = { Text("Negative prompt (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        item {
            OutlinedTextField(
                value = seedText,
                onValueChange = { seedText = it.filter(Char::isDigit).take(10) },
                label = { Text("Seed (optional)") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Button(
                onClick = {
                    if (prompt.isBlank()) { status = "Enter a prompt first."; return@Button }
                    if (model == ImageModel.QWEN2511 && refs.isEmpty()) { status = "Qwen Edit 2511 needs at least one reference image."; return@Button }
                    scope.launch {
                        busy = true; status = "Preparing input…"; result = null
                        runCatching {
                            val data = refs.mapIndexed { index, uri ->
                                status = "Preparing reference ${index + 1}/${refs.size}…"
                                MediaUtils.uriToJpegDataUri(context, uri)
                            }
                            status = "Generating with ${model.label}…"
                            val url = when (model) {
                                ImageModel.QWEN2 -> client.generateQwenImage2(
                                    prompt, data.firstOrNull(), ratio, matchInput, expandPrompt, negative,
                                    seedText.toLongOrNull()
                                )
                                ImageModel.QWEN2511 -> client.generateQwen2511(prompt, data, if (ratio == "1:1" && refs.isNotEmpty()) "match_input_image" else ratio, seedText.toLongOrNull())
                            }
                            status = "Saving result locally…"
                            val file = MediaUtils.downloadToInternal(context, url, CreationKind.IMAGE)
                            historyStore.add(CreationRecord(kind = CreationKind.IMAGE, model = model.label, prompt = prompt, localPath = file.absolutePath))
                            onHistoryChanged()
                            result = file
                            status = "Done"
                        }.onFailure { status = it.message ?: "Generation failed" }
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (busy) "Generating…" else "Generate image") }
        }
        status?.let { item { StatusCard(it, busy, openSettings) } }
        result?.let { file ->
            item {
                ResultImage(file)
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onAnimate(file) }, modifier = Modifier.weight(1f)) { Text("Animate with LTX") }
                    OutlinedButton(onClick = {
                        scope.launch { runCatching { MediaUtils.saveToGallery(context, file, CreationKind.IMAGE) }.onSuccess { status = "Saved to Pictures/Forge AI Studio" }.onFailure { status = it.message } }
                    }, modifier = Modifier.weight(1f)) { Text("Save") }
                }
            }
        }
    }
}

@Composable
fun VideoStudio(
    client: ReplicateClient,
    historyStore: HistoryStore,
    initialFile: File?,
    consumeInitialFile: () -> Unit,
    onHistoryChanged: () -> Unit,
    openSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var firstUri by remember { mutableStateOf<Uri?>(null) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var firstFile by remember { mutableStateOf<File?>(null) }
    var prompt by remember { mutableStateOf("") }
    var duration by remember { mutableIntStateOf(6) }
    var resolution by remember { mutableStateOf("1080p") }
    var ratio by remember { mutableStateOf("16:9") }
    var fps by remember { mutableIntStateOf(25) }
    var motion by remember { mutableStateOf("none") }
    var audio by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(initialFile?.absolutePath) {
        if (initialFile != null) {
            firstFile = initialFile
            firstUri = null
            result = null
            status = "Image loaded from Image Studio. Describe how it should move."
            consumeInitialFile()
        }
    }

    val firstPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { firstUri = uri; firstFile = null } }
    val lastPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> lastUri = uri }

    val invalidLongSetting = duration > 10 && (resolution != "1080p" || fps !in listOf(24, 25))

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { StudioHeader("Video Studio", "LTX‑2.3 Fast · text-to-video or image-to-video with synchronized audio.") }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (firstFile != null || firstUri != null) "First frame selected" else "First frame (optional)")
                    (firstFile ?: firstUri)?.let { source -> AsyncImage(source, null, Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { firstPicker.launch("image/*") }, enabled = !busy) { Text("Choose first frame") }
                        if (firstFile != null || firstUri != null) TextButton(onClick = { firstFile = null; firstUri = null }) { Text("Clear") }
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (lastUri == null) "Last frame (optional)" else "Last frame selected")
                    lastUri?.let { AsyncImage(it, null, Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { lastPicker.launch("image/*") }, enabled = firstFile != null || firstUri != null) { Text("Choose last frame") }
                        if (lastUri != null) TextButton(onClick = { lastUri = null }) { Text("Clear") }
                    }
                }
            }
        }
        item {
            OutlinedTextField(prompt, { prompt = it }, label = { Text("Describe the video") }, minLines = 4, modifier = Modifier.fillMaxWidth())
        }
        item { OptionRow("Duration", listOf("6", "8", "10", "12", "14", "16", "18", "20"), duration.toString()) { duration = it.toInt() } }
        item { OptionRow("Resolution", listOf("1080p", "2k", "4k"), resolution) { resolution = it } }
        item { OptionRow("Aspect ratio", listOf("16:9", "9:16"), ratio) { ratio = it } }
        item { OptionRow("FPS", listOf("24", "25", "48", "50"), fps.toString()) { fps = it.toInt() } }
        item { OptionRow("Camera", listOf("none", "static", "dolly_in", "dolly_out", "dolly_left", "dolly_right", "jib_up", "jib_down", "focus_shift"), motion) { motion = it } }
        item { ToggleRow("Generate synchronized audio", audio) { audio = it } }
        if (invalidLongSetting) item { Text("12–20 second clips require 1080p at 24 or 25 FPS.", color = MaterialTheme.colorScheme.error) }
        item {
            Button(
                onClick = {
                    if (prompt.isBlank()) { status = "Enter a video prompt first."; return@Button }
                    if (invalidLongSetting) { status = "Fix the duration/resolution/FPS combination first."; return@Button }
                    if (lastUri != null && firstFile == null && firstUri == null) { status = "A last frame requires a first frame."; return@Button }
                    scope.launch {
                        busy = true; result = null; status = "Preparing frames…"
                        runCatching {
                            val firstData = when {
                                firstFile != null -> MediaUtils.fileToJpegDataUri(firstFile!!)
                                firstUri != null -> MediaUtils.uriToJpegDataUri(context, firstUri!!)
                                else -> null
                            }
                            val lastData = lastUri?.let { MediaUtils.uriToJpegDataUri(context, it) }
                            status = "Generating with LTX‑2.3…"
                            val url = client.generateLtx23(prompt, firstData, lastData, duration, resolution, ratio, fps, motion, audio)
                            status = "Saving video locally…"
                            val file = MediaUtils.downloadToInternal(context, url, CreationKind.VIDEO)
                            historyStore.add(CreationRecord(kind = CreationKind.VIDEO, model = "LTX 2.3 Fast", prompt = prompt, localPath = file.absolutePath))
                            onHistoryChanged()
                            result = file
                            status = "Done"
                        }.onFailure { status = it.message ?: "Generation failed" }
                        busy = false
                    }
                },
                enabled = !busy && !invalidLongSetting,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (busy) "Generating…" else "Generate video") }
        }
        status?.let { item { StatusCard(it, busy, openSettings) } }
        result?.let { file ->
            item { VideoPlayer(file) }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        val uri = MediaUtils.shareUri(context, file)
                        context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Share video"))
                    }, modifier = Modifier.weight(1f)) { Text("Share") }
                    OutlinedButton(onClick = {
                        scope.launch { runCatching { MediaUtils.saveToGallery(context, file, CreationKind.VIDEO) }.onSuccess { status = "Saved to Movies/Forge AI Studio" }.onFailure { status = it.message } }
                    }, modifier = Modifier.weight(1f)) { Text("Save") }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(
    historyStore: HistoryStore,
    refreshKey: Int,
    onAnimate: (File) -> Unit,
    onChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val records = remember(refreshKey) { historyStore.load() }
    var message by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { StudioHeader("History", "The app caches completed generations locally because provider output links expire.") }
        message?.let { item { Text(it, color = MaterialTheme.colorScheme.primary) } }
        if (records.isEmpty()) item { Text("No creations yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(records, key = { it.id }) { record ->
            val file = File(record.localPath)
            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (record.kind == CreationKind.IMAGE) ResultImage(file) else VideoPlayer(file, compact = true)
                    Text(record.model, fontWeight = FontWeight.SemiBold)
                    Text(record.prompt, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(record.createdAt)), style = MaterialTheme.typography.labelSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (record.kind == CreationKind.IMAGE) Button(onClick = { onAnimate(file) }) { Text("Animate") }
                        OutlinedButton(onClick = {
                            scope.launch { runCatching { MediaUtils.saveToGallery(context, file, record.kind) }.onSuccess { message = "Saved to gallery" }.onFailure { message = it.message } }
                        }) { Text("Save") }
                        TextButton(onClick = { historyStore.delete(record); onChanged() }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(tokenStore: SecureTokenStore, client: ReplicateClient, done: () -> Unit) {
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(tokenStore.load().orEmpty()) }
    var show by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { StudioHeader("Settings", "Your Replicate token stays encrypted on this phone with Android Keystore.") }
        item {
            OutlinedTextField(
                value = token,
                onValueChange = { token = it.trim() },
                label = { Text("Replicate API token") },
                visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item { ToggleRow("Show token", show) { show = it } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { tokenStore.save(token); message = "Token saved securely." }, modifier = Modifier.weight(1f)) { Text("Save token") }
                OutlinedButton(
                    onClick = {
                        tokenStore.save(token)
                        scope.launch {
                            testing = true
                            message = runCatching { "Connected as ${client.testToken()}" }.getOrElse { it.message ?: "Connection failed" }
                            testing = false
                        }
                    },
                    enabled = !testing,
                    modifier = Modifier.weight(1f)
                ) { Text(if (testing) "Testing…" else "Test") }
            }
        }
        message?.let { item { Text(it, color = if (it.startsWith("Connected") || it.startsWith("Token saved")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) } }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Active models", fontWeight = FontWeight.Bold)
                    Text("Qwen Image 2 — latest unified Qwen generation/editing model")
                    Text("Qwen Image Edit 2511 — optional multi-reference editor")
                    Text("LTX‑2.3 Fast — image/text-to-video with audio")
                    Text("Provider: Replicate API. No Hugging Face daily ZeroGPU quota; usage is billed per generation.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Button(onClick = { tokenStore.save(token); done() }, enabled = token.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Open Studio") } }
    }
}

@Composable
private fun ResultImage(file: File) {
    AsyncImage(
        model = file,
        contentDescription = null,
        modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp, max = 520.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun VideoPlayer(file: File, compact: Boolean = false) {
    val context = LocalContext.current
    val player = remember(file.absolutePath) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
        update = { it.player = player },
        modifier = Modifier.fillMaxWidth().height(if (compact) 210.dp else 300.dp).clip(RoundedCornerShape(14.dp))
    )
}

@Composable
private fun OptionRow(label: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, fontWeight = FontWeight.SemiBold)
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options.size) { i ->
                val option = options[i]
                FilterChip(selected = option == selected, onClick = { onSelect(option) }, label = { Text(option) })
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun StatusCard(text: String, busy: Boolean, openSettings: () -> Unit) {
    Card {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (busy) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            Text(text, Modifier.weight(1f))
            if (text.contains("token", ignoreCase = true)) TextButton(onClick = openSettings) { Text("Settings") }
        }
    }
}
